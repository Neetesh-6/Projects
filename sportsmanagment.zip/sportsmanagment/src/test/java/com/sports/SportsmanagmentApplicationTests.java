package com.sports;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportsmanagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
