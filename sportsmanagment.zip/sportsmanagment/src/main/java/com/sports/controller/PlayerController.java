package com.sports.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.sports.dto.PlayerDTO;
import com.sports.entity.PlayerEntity;
import com.sports.service.PlayerService;
import com.sports.util.PlayerConverter;






@RestController
@RequestMapping("/api")
public class PlayerController {
	@Autowired
	private PlayerService playerservice;
	@Autowired
	private PlayerConverter playerconveter;
	@PostMapping("/CreatePlayer")
	public String createplayer(@RequestBody PlayerDTO playerDTO)
	{
		final PlayerEntity player= playerconveter.convertToEntity(playerDTO);
		 return playerservice.createplayer(player);	 
	}
	@PutMapping("/updateplayer/(identity)")
	 public PlayerDTO updatePlayer(@PathVariable("identity") int id, @RequestBody PlayerDTO playerDTO)
	  {
		PlayerEntity Player= playerconveter.convertToEntity(playerDTO);
		  return playerservice.updatePlayer(id, Player);
	  }
	@GetMapping("/getPlayer/{identity}")
    public PlayerDTO getPlayer(@PathVariable("identity") int id)
    {
    return playerservice.getPlayer(id);
    	
    }
	 @GetMapping("/getAllPlayer")
	    public List<PlayerDTO> getAllPlayer()
	    {
	    	return playerservice.getAllPlayer();
	    }
	 @DeleteMapping("/deletePlayerById/{id}")
	    public String deletePlayerById(@PathVariable("id") int id)
	    {
	    	return playerservice.deletePlayerById(id);
	    	
	    }
	 @PostMapping("/assignSportsToPlayer/{playerid}/{sportsid}")
	 public PlayerDTO assignSportsToPlayer(@PathVariable("playerid") int id,@PathVariable("sportsid") int sportsid) {
		 return playerservice.assignSportToPlayer(id,sportsid);
	 }
	 }

