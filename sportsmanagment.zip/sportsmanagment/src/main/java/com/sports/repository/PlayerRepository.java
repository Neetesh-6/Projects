package com.sports.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.sports.dto.PlayerDTO;
import com.sports.entity.PlayerEntity;

public interface PlayerRepository extends JpaRepository<PlayerEntity,Integer> {


}
