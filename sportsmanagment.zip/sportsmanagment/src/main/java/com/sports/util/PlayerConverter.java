package com.sports.util;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import com.sports.dto.PlayerDTO;
import com.sports.entity.PlayerEntity;



@Component
public class PlayerConverter {
	public PlayerEntity convertToEntity( PlayerDTO playerDTO) 
	{
		PlayerEntity player = new PlayerEntity();
		if(playerDTO!=null)
   	 {
   		 BeanUtils.copyProperties(playerDTO, player);
   	 }
   	 return player;
   }
	//convert the player to playerDTO(toplayer,fromplayerDTO)
	public PlayerDTO convertToDTO(PlayerEntity player)
	{
		PlayerDTO playerDTO = new PlayerDTO();
		if(player!=null)
		{
			BeanUtils.copyProperties(player,playerDTO);	
		}
		return playerDTO;
}
}
