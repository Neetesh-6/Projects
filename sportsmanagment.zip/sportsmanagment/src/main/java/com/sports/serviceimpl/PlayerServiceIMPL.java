package com.sports.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.sports.dto.PlayerDTO;
import com.sports.entity.PlayerEntity;
import com.sports.entity.SportsEntity;
import com.sports.exception.ResourceNotFoundException;
import com.sports.repository.PlayerRepository;
import com.sports.repository.SportsRepository;
import com.sports.service.PlayerService;
import com.sports.util.PlayerConverter;


@Service
public class PlayerServiceIMPL implements PlayerService {
	@Autowired
	private PlayerRepository playerrepository;
	@Autowired
	private PlayerConverter playerconveter;
	@Autowired
	private SportsRepository sportsrepository;
	@Override
	public String createplayer(PlayerEntity player) {
		String message=null;
		playerrepository.save(player);
		if(player!=null)
		{
			message ="Player details saved successfuly";
		}
			return message;
	}
	@Override
	public PlayerDTO updatePlayer(int id, PlayerEntity player) {
		PlayerEntity existingPlayer= playerrepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("PlayerEntity", "ID", id));
		existingPlayer.setPlayerName(player.getPlayerName());
			existingPlayer.setPlayerTeam(player.getPlayerTeam());
			existingPlayer.setPlaySports(player.getPlaySports());
		playerrepository.save(existingPlayer);
			return playerconveter.convertToDTO(existingPlayer);
	}
	@Override
	public PlayerDTO getPlayer(int id)
		{
			  PlayerEntity getPlayer= playerrepository.findById(id).get();
			  return playerconveter.convertToDTO(getPlayer);
	}
	@Override
	public List<PlayerDTO> getAllPlayer()
		{
			 List<PlayerEntity> sports=playerrepository.findAll();
			 List<PlayerDTO> sDTO = new ArrayList<>();
			 for(PlayerEntity s:sports)
			 {
				 sDTO.add(playerconveter.convertToDTO(s));
			 }
			 return sDTO;
	}
	@Override
	public String deletePlayerById(int id) {
		String message= null;
		 Optional<PlayerEntity> sports=playerrepository.findById(id);
		 if(sports.isPresent())
		 {
			 playerrepository.deleteById(id);
			 message="sports details delete successfully";
		 }
		 else
		 {
			 message="Sports details not found";
		 }
		 return message;
	}
@Override
	public PlayerDTO assignSportsToPlayer(int id,int sportsid) {
	PlayerEntity player=playerrepository.findById(id).get();
    SportsEntity sports=sportsrepository.findById(sportsid).get();
    player.setSports(sports);
    playerrepository.save(player);
    return playerconveter.convertToDTO(player);
}
@Override
public PlayerDTO assignSportToPlayer(int id, int sportsid) {
	// TODO Auto-generated method stub
	return null;
}
	

	
	}

	

