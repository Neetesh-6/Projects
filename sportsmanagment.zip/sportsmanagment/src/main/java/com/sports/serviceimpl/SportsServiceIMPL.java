package com.sports.serviceimpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sports.dto.SportsDTO;
import com.sports.entity.SportsEntity;
import com.sports.repository.SportsRepository;
import com.sports.service.SportsService;
import com.sports.util.SportsConverter;




@Service
public class SportsServiceIMPL implements SportsService {
	@Autowired
	private SportsRepository sportsrepository; 
	@Autowired
	private SportsConverter sportsconverter;
	@Override
	public String createSports(SportsEntity sports) 
	{
		String message=null;
		sportsrepository.save(sports);
		if(sports!=null)
		{
			message ="Sports details saved successfuly";
		}
			return message;
		}
	@Override
	public SportsDTO updateSports(int Id ,SportsEntity sports) {
		SportsEntity existingSports= sportsrepository.findById(Id).get();
		existingSports.setSportsname(sports.getSportsname());
		existingSports.setLocation(sports.getLocation());
		existingSports.setTeamname(sports.getTeamname());
	sportsrepository.save(existingSports);
		return sportsconverter.convertToSportsDTO(existingSports);
	}
	@Override
	public SportsDTO getSports(int id) 
	{
		 SportsEntity getSports= sportsrepository.findById(id).get();
		 
		  return sportsconverter.convertToSportsDTO(getSports);
	}
	@Override
	public List<SportsDTO> getAllSports() 
	{
		 List<SportsEntity> sports=sportsrepository.findAll();
		 List<SportsDTO> sDTO = new ArrayList<>();
		 for(SportsEntity s:sports)
		 {
			 sDTO.add(sportsconverter.convertToSportsDTO(s));
		 }
		 return sDTO;
	}
	@Override
	public String deleteSportsById(int id) 
	{
		 String message= null;
		 Optional<SportsEntity> sports=sportsrepository.findById(id);
		 if(sports.isPresent())
		 {
			 sportsrepository.deleteById(id);
			 message="sports details delete successfully";
		 }
		 else
		 {
			 message="Sports details not found";
		 }
		 return message;
	}
	@Override
	public void deleteAllSports() 
	{
		sportsrepository.deleteAll();
	}
		
	}

