package com.sports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportsmanagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportsmanagmentApplication.class, args);
		System.out.println("SportsManagement Application is Running Sucessfull");
	}

}
