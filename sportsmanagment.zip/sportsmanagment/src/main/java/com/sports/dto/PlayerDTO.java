package com.sports.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PlayerDTO {
	private  int id;
	private String playerName;
	private String playerTeam;
	private String playSports;
	private String PlayerSports;
}
