package com.sports.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="sports")

public class SportsEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private  int sportsid;
	@Column(name="sports_name")
	private String sportsname;
	@Column(name="sports_location")
	private String location;
	@Column(name="teamname")
	private String teamname;
	@Column(name="duration")
	private float duration;
}
